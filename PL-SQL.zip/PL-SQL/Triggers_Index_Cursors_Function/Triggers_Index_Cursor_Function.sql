SET SERVEROUTPUT ON
create table emp_1 as (select employee_id, department_id from employees);
?create table dept_1 as (select department_id, department_name from departments);
?
select * from dept_1;
select * from emp_1;
?
create view vw_emp1 as
select employee_id, d.department_id, department_name
from emp_1 e, dept_1 d
where e.department_id = d.department_id;
?
drop view VW_EMP1;
select * from VW_EMP1 where department_id = 90;
?
insert into VW_EMP1 values (1, 1234,'newdept');
?
CREATE OR REPLACE TRIGGER tr_vw_emp1
INSTEAD OF INSERT ON VW_EMP1
FOR EACH ROW
?
DECLARE
?
    n_dept_id NUMBER;
BEGIN
    -- insert first in the dept_1
    INSERT INTO dept_1 (department_id, department_name) values (:NEW.department_id, :NEW.department_name)
    RETURNING department_id INTO n_dept_id;
    
    -- insert for emp_1
    INSERT INTO emp_1 (employee_id, department_id) values (:NEW.employee_id, n_dept_id);
END;
/
?
?
select * from dept_1;
?
select * from emp_1;
?
select * from VW_EMP1;

create table emp as (select * from employees);
CREATE or replace PROCEDURE remove_emp (employee_id NUMBER) AS
   tot_emps NUMBER;
   BEGIN
      DELETE FROM emp
      WHERE emp.employee_id = remove_emp.employee_id;
   tot_emps := tot_emps - 1;
   END;
/
?
select * from emp;
exec remove_emp(102);




