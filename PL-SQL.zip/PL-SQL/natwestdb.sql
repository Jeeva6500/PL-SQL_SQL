select * from Employees;


select city, count(employee_id)
from employees e, departments d, locations l
where e.department_id = d.department_id
and d.location_id = l.location_id
group by city;

select department_name, city
from departments d, locations l
where d.location_id = l.location_id;

select department_name, sum(salary)
From employees e, departments d
where e.department_id = d.department_id
group by department_name;

select first_name from employees where first_name like 'S%';

select * from employees where department_id = 100;


select first_name, job_id, salary from employees;

select count(employee_id) as number_of_employees from employees;

select first_name, salary from employees order by salary ASC;

select first_name from employees order by first_name ASC;


SET SERVEROUTPUT ON
create or replace PROCEDURE cal_salary
(in_emp_id IN employees.employee_id%type, in_bonus in number)
is
begin
update employees
set salary = salary + salary*in_bonus/100
where employee_id = in_emp_id;
end;
/
execute cal_salary(100,5)

select * from employees;

SET SERVEROUTPUT ON
DECLARE
  l_customer_name employees.first_name%TYPE;
  l_salary employees.salary%TYPE;
BEGIN
  SELECT
    first_name, salary
  INTO
    l_customer_name, l_salary
  FROM
    employees
  WHERE
    employee_id = 100;
  DBMS_OUTPUT.PUT_LINE(l_customer_name || ':' || l_salary );
END;
/

SET SERVEROUTPUT ON
DECLARE
    l_salary   employees.salary%TYPE;
    l_average_salary l_salary%TYPE;
    l_max_salary     l_salary%TYPE;
    l_min_salary     l_salary%TYPE;
BEGIN
    -- get credit limits
    SELECT 
        MIN(salary), 
        MAX(salary), 
        AVG(salary)
    INTO 
        l_min_salary,
        l_max_salary, 
        l_average_salary
    FROM employees;
    
    
    SELECT 
        salary
    INTO 
        l_salary
    FROM 
        employees
    WHERE 
        employee_id = 100;
    -- show the credits     
    dbms_output.put_line('Min Credit: ' || l_max_salary);
    dbms_output.put_line('Max Credit: ' || l_max_salary);
    dbms_output.put_line('Avg Credit: ' || l_average_salary);
    -- show customer credit    
    dbms_output.put_line('Customer Credit: ' || l_salary);
END;
/
SET SERVEROUTPUT ON
declare
n_salary employees.salary%type;
max_salary n_salary%type;
min_salary n_salary%type;
avg_salary n_salary%type;

begin
select max(salary), min(salary),avg(salary)
into max_salary,min_salary,avg_salary from employees;
    dbms_output.put_line('Min Credit: ' || min_salary);
    dbms_output.put_line('Max Credit: ' || max_salary);
    dbms_output.put_line('Avg Credit: ' || avg_salary);
end;
/


SET SERVEROUTPUT ON
DECLARE
n_eid employees.employee_id%type := &employee_id;
begin
dbms_output.put_line('The salary is: ' ||n_eid);
end;
/

create table emp as (select * from employees);
CREATE or replace PROCEDURE remove_emp (employee_id NUMBER) AS
   tot_emps NUMBER;
   BEGIN
      DELETE FROM emp
      WHERE emp.employee_id = remove_emp.employee_id;
   tot_emps := tot_emps - 1;
   END;
/
?
select * from emp;
exec remove_emp(102);


create or replace procedure print_emp






