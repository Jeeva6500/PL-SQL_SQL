create database natwestdb;
use natwestdb;

CREATE TABLE location (
locid int PRIMARY KEY,
city varchar(20) NOT NULL,
pincode varchar(6) CHECK (pincode >5 )
); 

drop table location;
drop table dept;
drop table employee;
drop table employeedetails;

CREATE TABLE dept (
deptid int,
deptname varchar(30) NOT NULL,
locid int,
CONSTRAINT deptid_pk primary key (deptid),
CONSTRAINT locid_fk foreign key (locid) references location (locid)
);

describe location; 
describe dept;

CREATE TABLE employee (
empid int PRIMARY KEY,
empname varchar(30) NOT NULL UNIQUE,
email varchar(30) UNIQUE NOT NULL,
phoneno varchar(10) NOT NULL unique CHECK (phoneno>9),
deptid int references dept (deptid),
CONSTRAINT deptid_fk foreign key (deptid) references dept (deptid),
CONSTRAINT email_chk CHECK (email like '%@%')
);

describe employee;

CREATE TABLE employeedetails (
empid int PRIMARY KEY,
gender varchar(6) CHECK (gender in ('MALE' and 'FEMALE')),
doj date,
dob date,
CONSTRAINT empid_fk foreign key (empid) references employee (empid)
);

ALTER TABLE employeedetails add column bloodgroup varchar(10);

ALTER TABLE employeedetails modify column bloodgroup varchar(12) NOT NULL;

desc employeedetails;

ALTER TABLE employeedetails rename column bloodgroup to bgroup;

desc employeedetails;

INSERT INTO location(locid, city, pincode) values (101, 'Chennai', '600102' );
INSERT INTO location values (102, 'Bangalore', '562125'), (103, 'Delhi', '112125'), (104, 'Mumbai', '412123');

select * from location;

INSERT INTO dept values (1001, 'Finance', '101'), (1002, 'Sales', '102'), (1003, 'HR', '103'), (1004, 'IT', '104');

select * from dept;

INSERT INTO employee values (712425, 'Jeeva', 'jeeva@gmail.com', '1212121212', 1001), 
							(712426, 'John', 'johna@gmail.com', '2323232323', 1001), 
                            (712427, 'Syed', 'syed@gmail.com', '7878787878', 1001), 
                            (712428, 'Raveena', 'raveena@gmail.com', '4545454545', 1002), 
                            (712429, 'Priya', 'priya@gmail.com', '1414141414', 1002), 
                            (712430, 'Suresh', 'suresh@gmail.com', '5252525252', 1002), 
                            (712431, 'Mani', 'mani@gmail.com', '6363636363', 1003), 
                            (712432, 'Renuka', 'renuka@gmail.com', '1020301020', 1003), 
                            (712433, 'Ramesh', 'ramesh@gmail.com', '2030105060', 1003), 
                            (712434, 'Ramya', 'ramya@gmail.com', '4050635258', 1004), 
                            (712437, 'Daniel', 'daniel@gmail.com', '9896969652', 1004), 
                            (712435, 'Mustafa', 'mustafa@gmail.com', '8575252524', 1004), 
                            (712436, 'Pinky', 'pinky@gmail.com', '7585952562', 1001);
                            
UPDATE location set city = 'Kolkata' where locid = 104;

select * from location;

select empname, phoneno from employee;
select empname from employee where deptid = 1002;

select empname from employee where deptid = 1003 order by empname desc;

select empname from employee where empname like 'R%';

select * from employee order by empname, email;

select * from employee order by 5, 3;

select * from employee where deptid in (select deptid from dept where locid in (select locid from location where city = 'Bangalore'));

select * from employee where deptid in (select deptid from dept where deptname = 'HR');

select empname, deptname from employee, dept where employee.deptid = dept.deptid;

select empname, deptname, city from employee, dept, location where employee.deptid = dept.deptid and dept.locid = location.locid;



