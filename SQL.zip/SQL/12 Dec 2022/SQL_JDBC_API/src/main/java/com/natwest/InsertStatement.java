package com.natwest;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class InsertStatement {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		
		
		String url = "jdbc:mysql://localhost:3306/natwestdb";
		String username = "root";
		String password = "root";
		
		Connection con = DriverManager.getConnection(url, username, password);
		
		String query = "INSERT into EMPLOYEE values (?,?,?,?,?)";
		
		Scanner sc = new Scanner (System.in);
		
		System.out.println("Enter the employee id: ");
		int id = sc.nextInt();
		
		System.out.println("Enter employee name: ");
		String name = sc.next();
		
		System.out.println("Enter email id: ");
		String email = sc.next();
		
		System.out.println("Enter phone number: ");
		String phone = sc.next();
		
		System.out.println("Enter dept id: ");
		int deptid = sc.nextInt();
		
		PreparedStatement preStm = con.prepareStatement(query);
		
		preStm.setInt(1, id);
		preStm.setString(2, name);
		preStm.setString(3, email);
		preStm.setString(4, phone);
		preStm.setInt(5, deptid);
		
		System.out.println(preStm);
		
		int res = preStm.executeUpdate();
		
		if (res > 0) {
			System.out.println("Record inserted");
		} else {
			System.out.println("Record not inserted");
		}
		
		preStm.close();
		sc.close();
		con.close();
		
		
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
