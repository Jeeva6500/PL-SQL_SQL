package com.natwest;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class SelectStatement {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			String url = "jdbc:mysql://localhost:3306/natwestdb";
			String username = "root";
			String password = "root";
			
			Connection con;
		
			con = DriverManager.getConnection(url, username, password);
						
			String query = "SELECT * from EMPLOYEE;";
			
			Statement stm = con.createStatement();
			
			ResultSet result = stm.executeQuery(query); //will have the actual data of your table
			
			ResultSetMetaData metainfo = result.getMetaData();
			
			int count = metainfo.getColumnCount();
			
			int i = 1;
			
			while(i<=count) {
				System.out.print(metainfo.getColumnName(i) + " ");
				i++;
			}
			System.out.println();
			
			while(result.next()) {
				System.out.print(result.getInt("empid")+ " ");
				System.out.print(result.getString(2)+ " ");		
				System.out.print(result.getString(3)+ " ");
				System.out.print(result.getString(4)+ " ");
				System.out.print(result.getInt("deptid")+ " ");
				System.out.println();
			}
			
			result.close();
			stm.close();
			con.close();
			
		} catch (ClassNotFoundException e) {
			System.out.println("Check the driver class or dependency");
		} catch (SQLException e) {
			System.out.println("Check your SQL syntax: " + e.getMessage());
		}

	
	}

}
