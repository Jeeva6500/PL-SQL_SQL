package com.natwest;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class UpdateStatement {

	public static void main(String[] args) {
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		
		
		String url = "jdbc:mysql://localhost:3306/natwestdb";
		String username = "root";
		String password = "root";
		
		Connection con = DriverManager.getConnection(url, username, password);
		
		String query = "UPDATE EMPLOYEE set empname=?, phoneno=? where empid=?";
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter employee id which you want to update: ");
		int id = sc.nextInt();
		
		System.out.println("Enter the name to update: ");
		String name = sc.next();
		
		System.out.println("Enter phone number to update: ");
		String phone = sc.next();
		
		PreparedStatement preStm = con.prepareStatement(query);
		
		
		preStm.setString(1, name);
		preStm.setString(2, phone);
		preStm.setInt(3, id);
		
		System.out.println(preStm);
		
		int output = preStm.executeUpdate();
		
		if (output>0) {
			System.out.println("Record updated");
					}
		else {
			System.out.println("Record not updated");
		}
		
		preStm.close();
		sc.close();
		con.close();
		
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		}
		
		catch (SQLException e) {
			e.printStackTrace();
		}
		

	}

}
